﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariousArray
{
    class Program
    {
        static void Main(string[] args)
        {
            // 배열을 생성합니다.
            int[] intArray = new int[100];

            // 요소의 길이를 출력합니다.
            Console.WriteLine(intArray[0]);
            Console.WriteLine(intArray[99]);
        }
    }
}
