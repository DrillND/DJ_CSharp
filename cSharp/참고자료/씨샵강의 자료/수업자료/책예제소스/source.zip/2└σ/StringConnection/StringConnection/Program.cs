﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringConnection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("가나다" + "라마" + "바사아" + "자차카타" + "파하");
        }
    }
}
