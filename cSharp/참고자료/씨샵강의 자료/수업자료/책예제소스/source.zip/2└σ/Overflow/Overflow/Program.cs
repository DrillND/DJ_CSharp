﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overflow
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 2000000000;
            int b = 1000000000;
            Console.WriteLine(a + b);
        }
    }
}
