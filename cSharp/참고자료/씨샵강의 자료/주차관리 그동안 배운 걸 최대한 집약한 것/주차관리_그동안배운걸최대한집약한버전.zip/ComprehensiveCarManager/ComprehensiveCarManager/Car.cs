﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComprehensiveCarManager
{
    class Car
    {
        public string carNumber { get; set; }
    }
}
